document.addEventListener("DOMContentLoaded", function(event) {
  let canvas = new fabric.Canvas("canvas");
  canvas.add(
    new fabric.Rect({
      width: 100,
      height: 200,
      left: 300,
      top: 100,
      fill: 'green',
      angle: 45
    }));

    canvas.add(new fabric.Circle({
      radius:100,
      left: 300,
      top: 100,
      fill: 'yellow',
      angle: 45,
      selectable: true
    }));

    canvas.add(new fabric.Text("sample for Vlad and Benjamin",{
      fontFamily: "Georgia",
      top: 200,
      left: 300,
    }));
});
